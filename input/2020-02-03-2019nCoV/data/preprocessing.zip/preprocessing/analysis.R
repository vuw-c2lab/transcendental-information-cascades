library(readr)
library("Biostrings")
library(plotly)

library(ggthemes)
library(ggpubr)
library(latex2exp)
library(ggrepel)
library(scales)
library(GGally)
library(nonlinearTseries)
options(scipen=100000)

# plot coordinates -----

TICCoordinates <- read_csv("~/OneDrive - Victoria University of Wellington - STAFF/Git/transcendental-information-cascades/output/2020-02-03-2019nCoV/ordered-discrete-genes-CODON-samplesequence-2020-02-05-00-35-25/createTIC/TICCoordinates.csv")

plot_ly(x=TICCoordinates$t,
        y=TICCoordinates$specificity,
        z =TICCoordinates$diversity, 
        type = "scatter3d",mode="markers",opacity=0.5) 

# plot info theory metrics -----

TICInfoTheory <- read_csv("~/OneDrive - Victoria University of Wellington - STAFF/Git/transcendental-information-cascades/output/2020-02-03-2019nCoV/ordered-discrete-genes-CODON-samplesequence-2020-02-05-00-35-25/createTIC/TICInfoTheory2.csv")

plot(TICInfoTheory$ShannonWiener,type='l', xlab="Node index", ylab="Shannon entropy of unique codon matches")
plot(TICInfoTheory$Pielou,type='l', xlab="Node index", ylab="Pielou evenness of unique codon matches")


ggplot() +
  geom_line(aes(x=c(1:nrow(TICInfoTheory)), y=TICInfoTheory$ShannonWiener))+
  #geom_line(aes(x=c(1:nrow(TICInfoTheory)), y=TICInfoTheory$Pielou)) +
  theme_minimal() + 
  xlab("Progression stage") + ylab("Shannon entropy of unique codon identifiers") +
  NULL

# visualise TIC network ----

library(igraph)
links <- read_csv("~/OneDrive - Victoria University of Wellington - STAFF/Git/transcendental-information-cascades/output/2020-02-03-2019nCoV/ordered-discrete-genes-CODON-samplesequence-2020-02-05-00-35-25/createTIC/links.csv")
nodes <- read_csv("~/OneDrive - Victoria University of Wellington - STAFF/Git/transcendental-information-cascades/output/2020-02-03-2019nCoV/ordered-discrete-genes-CODON-samplesequence-2020-02-05-00-35-25/createTIC/nodes.csv")
colnames(links) <- c("id1","id2","label")
agg_links <- aggregate(label ~ .,links,paste, collapse = ", ")
agg_links$weight <- sapply(agg_links$label,function(x){stringr::str_count(x,", ")+1})

links.dist <- links
links.dist$dist <- links.dist$target - links.dist$source
links.dist.dens <- plyr::count(links.dist$dist)
links.dist.dens <- links.dist.dens[order(-links.dist.dens$freq),]
plot(links.dist.dens,pch=19)
plot(links.dist.dens,log='xy',pch=19)
write_csv(links.dist.dens,"link_dist.csv")

agg_links$id1 <- paste0(rownames(output)[agg_links$id1]," - ",output$X2[agg_links$id1])
agg_links$id2 <- paste0(rownames(output)[agg_links$id2]," - ",output$X2[agg_links$id2])

g <- graph_from_data_frame(as.data.frame(agg_links),directed = T)
#V(g)$label <- output$X2
#V(g)$name <- output$X2
adj <- as_adj(g, attr = "weight")
write_csv(as.data.frame(as.matrix(adj)),"adj.csv",col_names = F)

colnames(agg_links) <- c("Source","Target","label", "weight")
write_csv(agg_links,"weighted.csv")

agg_links.weightsonly <- agg_links[,-3]
agg_links.weightsonly <- agg_links.weightsonly[order(-agg_links.weightsonly$weight),]
write_csv(agg_links.weightsonly,"link_weights.csv")

V(g)$size <- 3
V(g)$frame.color <- "white"
V(g)$color <- "orange"
E(g)$arrow.mode <- 1
#E(g)$label <- links$label

l <- layout_with_dh(g)
l <- layout_as_star(g)

plot(g, layout=l, edge.label = NA,edge.arrow.size = 0.05)

palf <- colorRampPalette(c("gold", "dark orange")) 
netm <- as.matrix(read_csv("~/OneDrive - Victoria University of Wellington - STAFF/Git/transcendental-information-cascades/output/2020-02-03-2019nCoV/ordered-discrete-genes-CODON-samplesequence-2020-02-05-00-35-25/createTIC/TICmatrix.csv"))
heatmap(netm, Rowv = NA, Colv = NA, col = palf(100), scale="none", margins=c(10,10) )

# cluster analysis ----
wtc <- cluster_walktrap(g)
clus <- membership(wtc)
clus.df <- data.frame(vir=names(clus), cluster=c(clus))

clus.df <- clus.df[order(clus.df$cluster),]
write_csv(clus.df,"clusters.csv")

head(clus.df)

#intra cluster similarity

allClusterSims <- list()
for(i in sort(unique(clus.df$cluster))){
  #get all virs in cluster
  virs <- gsub("[[:digit:]]+ - ","",as.character(clus.df$vir[which(clus.df$cluster==i)]))
  
  #permutartions
  intraSim <- list()
  virs.comb <- gtools::combinations(n=length(virs),2,virs,repeats.allowed = F)
  for(j in 1:nrow(virs.comb)){
    dna1 <- toString(output[which(output$X2==virs.comb[j,1]),4])
    dna1.len <- nchar(dna1)
    dna2 <- toString(output[which(output$X2==virs.comb[j,2]),4])
    dna2.len <- nchar(dna2)
    thresh <- min(dna1.len,dna2.len)
    comp <- compareStrings(substr(dna1,1,thresh), substr(dna2,1,thresh))
    comp.split <- unlist(strsplit(comp,""))
    dnaDiff <- length(which(comp.split=="?"))
    intraSim[[length(intraSim)+1]] <- 1 - (dnaDiff/thresh)
  }
  
  allClusterSims[[length(allClusterSims)+1]] <- intraSim
}

avgSim <- lapply(allClusterSims,function(x){
  c(mean(unlist(x)),sd(unlist(x)),min(unlist(x)),max(unlist(x)))
})

clSizes <- plyr::count(clus.df$cluster)

plotData <- data.frame(lab=sort(unique(clus.df$cluster)),avgSim=unlist(avgSim)[seq(from=1,to=length(unlist(avgSim)),by=4)],sdSim=unlist(avgSim)[seq(from=2,to=length(unlist(avgSim)),by=4)],minSim=unlist(avgSim)[seq(from=3,to=length(unlist(avgSim)),by=4)],maxSim=unlist(avgSim)[seq(from=4,to=length(unlist(avgSim)),by=4)],clSize=clSizes$freq)

ggplot(data=plotData, aes(x=as.character(lab), y=avgSim)) +
  geom_bar(stat="identity", fill="#E69F00")+
  geom_text(aes(label=round(avgSim,2)), vjust=1.6, color="white", size=3.5)+
  theme_minimal() + 
  xlab("Cluster") + ylab("Avg similarity") +
  NULL

write_csv(plotData,"clusterstat.csv")

rownames(clus.df) <- c()
colnames(clus.df) <- c("id", "cluster")
clus.df$id <- as.character(clus.df$id)
write_csv(clus.df,"nodes.csv")

# inter cluster similarity

clusIds <- sort(unique(clus.df$cluster))
clusIds.combs <- gtools::combinations(n=length(clusIds),2,clusIds,repeats.allowed = F)

allInterClusterSims <- list()

for(i in 1:nrow(clusIds.combs)){
  nextComb1 <- clusIds.combs[i,1]
  nextComb2 <- clusIds.combs[i,2]
  
  nextComb1.virs <- gsub("[[:digit:]]+ - ","",as.character(clus.df$id[which(clus.df$cluster==nextComb1)]))
  nextComb2.virs <- gsub("[[:digit:]]+ - ","",as.character(clus.df$id[which(clus.df$cluster==nextComb2)]))
  
  interCombs <- expand.grid(nextComb1.virs,nextComb2.virs)
  interSim <- list()
  for(j in 1:nrow(interCombs)){
    dna1 <- toString(output[which(output$X2==interCombs[j,1]),4])
    dna1.len <- nchar(dna1)
    dna2 <- toString(output[which(output$X2==interCombs[j,2]),4])
    dna2.len <- nchar(dna2)
    thresh <- min(dna1.len,dna2.len)
    comp <- compareStrings(substr(dna1,1,thresh), substr(dna2,1,thresh))
    comp.split <- unlist(strsplit(comp,""))
    dnaDiff <- length(which(comp.split=="?"))
    interSim[[length(interSim)+1]] <- 1 - (dnaDiff/thresh)
  }
  allInterClusterSims[[paste0(clusIds.combs[i,],collapse="-")]] <- interSim
}

pairNames <- names(allInterClusterSims)

avgSim <- lapply(allInterClusterSims,function(x){
  c(mean(unlist(x)),sd(unlist(x)),min(unlist(x)),max(unlist(x)))
})

plotData <- data.frame(lab=pairNames,avgSim=unlist(avgSim)[seq(from=1,to=length(unlist(avgSim)),by=4)],sdSim=unlist(avgSim)[seq(from=2,to=length(unlist(avgSim)),by=4)],minSim=unlist(avgSim)[seq(from=3,to=length(unlist(avgSim)),by=4)],maxSim=unlist(avgSim)[seq(from=4,to=length(unlist(avgSim)),by=4)])
write_csv(plotData,"interclusterstat.csv")
ggplot(data=plotData, aes(x=lab, y=avgSim)) +
  geom_bar(stat="identity", fill="#E69F00")+
  geom_text(aes(label=round(avgSim,2)), vjust=1.6, color="white", size=3.5)+
  theme_minimal() +
  xlab("Inter-cluster pair") + ylab("Avg similarity") +
  NULL

# RQA ----
rq0bj <- rqa(time.series = TICCoordinates$diversity,radius = 1,time.lag = 1)
plot(rq0bj)
write_csv(as.data.frame(TICCoordinates$diversity),"div_series.csv")
