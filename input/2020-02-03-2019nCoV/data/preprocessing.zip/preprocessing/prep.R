library("Biostrings")
library(stringr)
library(lubridate)
library(tesseract)
library(readr)

fils <- gsub(".fasta","",list.files("data/",full.names = F))

for(fil in fils){
  dna <- toString(readDNAStringSet(paste0("data/",fil,".fasta")))
  meta <- ocr(paste0("metadata/",fil,".pdf"))
  
  dcol <- gsub("Collection date: ","",str_match(meta,"Collection date: [0-9]+-[0-9]+-[0-9]+"))[1]
  loc <- gsub("Location: ","",str_match(meta,"Location: [A-Za-z /]+"))[1]
  vname <- gsub("Virus name: ","",str_match(meta,"Virus name: [-A-Za-z /0-9]+"))
  originating_lab <- gsub("Originating lab: ","",str_match(meta,"Originating lab: [-A-Za-z /0-9\\.]+"))
  lab_adr <- gsub("Address: ","",str_match(meta,"Address: [-A-Za-z /0-9\\.,]+"))
  submitting_lab <- gsub("Submitting lab: ","",str_match(meta,"Submitting lab: [-A-Za-z /0-9\\.,]+"))
  authors <- gsub("Authors: ","",str_match(meta,"Authors: [-A-Za-z /0-9\\.,]+"))
  write_csv(data.frame(dcol=dcol,
                       vname=vname,
                       loc=loc,
                       dna=dna,
                       originating_lab=originating_lab,
                       lab_adr=lab_adr,
                       submitting_lab=submitting_lab,
                       authors=authors,
                       stringsAsFactors = F),"output.csv",append = T)
}

output <- output[order(output$X1),]
output <- output[which(!is.na(output$X1)),]
output <- output[which(nchar(output$X4)>=29000),]

write_csv(as.data.frame(output[,-c(3:4)]),"metalabs.csv")

clean_output <- output[which(!is.na(output$X1)),]
clean_output <- clean_output[order(clean_output$X1),]

clean_output <- clean_output[which(nchar(clean_output$X4)>=29000),]

write_csv(as.data.frame(clean_output$X4),"ordered.txt")
